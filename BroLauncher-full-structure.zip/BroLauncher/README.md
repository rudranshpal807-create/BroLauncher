# BroLauncher

Android Java starter structure for the BroLauncher project.

## Important
This repository is a **starter scaffold**, not a complete Minecraft runtime.
Minecraft Java on Android requires a compatible runtime/renderer and platform
integration. Ely.by authentication also needs to be integrated with the game
runtime's Yggdrasil/Authlib authentication flow.

## Open in Android Studio
1. Open the `BroLauncher` folder.
2. Let Android Studio sync Gradle.
3. If the Gradle wrapper is missing, run `gradle wrapper --gradle-version 8.9`
   from the project root (or create the wrapper using Android Studio).
4. Build with `./gradlew assembleDebug`.

## Ely.by
See `app/src/main/java/com/bro/launcher/auth/ElyByAuth.java`.
Do not hard-code credentials, commit tokens, or store account passwords.
Prefer a supported OAuth flow when available. Verify the current Ely.by
documentation and service requirements before shipping.

## Resource folders
- `res/layout`: Android XML layouts
- `res/drawable`: UI graphics and vector drawables
- `res/mipmap-*`: launcher icons at density-specific sizes
- `res/values`: strings, colors, themes and dimensions
- `res/xml`: Android XML configuration resources
- `assets`: files read directly by the app (not compiled as Android resources)
- `test`: local JVM unit tests
- `androidTest`: tests that run on an Android device/emulator
