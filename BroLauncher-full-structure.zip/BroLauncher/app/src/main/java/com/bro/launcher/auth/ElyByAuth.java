package com.bro.launcher.auth;

/**
 * Ely.by authentication integration point.
 *
 * Important:
 * - Never hard-code or commit a user's password or access token.
 * - Prefer Ely.by's currently supported OAuth flow where applicable.
 * - If implementing Yggdrasil endpoints, follow the current official API docs.
 * - A successful account login alone does not configure Minecraft's runtime;
 *   the game runtime must use a compatible authentication library/provider.
 */
public final class ElyByAuth {
    public static final String AUTH_BASE_URL = "https://authserver.ely.by";

    private ElyByAuth() {}

    /** TODO: Implement the documented Ely.by authentication flow securely. */
}
