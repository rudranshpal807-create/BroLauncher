package com.bro.launcher.auth;

/** Coordinates account providers. Implement provider selection and session handling. */
public class AuthManager {
    // TODO: Add Ely.by, Microsoft, and offline account flows.
}
