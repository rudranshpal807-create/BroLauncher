package com.bro.launcher.auth;

/** TODO: Implement offline profile support where legally and technically appropriate. */
public class OfflineAuth {}
