package com.bro.launcher.ui;

/** TODO: Create launcher settings UI. */
public class SettingsActivity {}
