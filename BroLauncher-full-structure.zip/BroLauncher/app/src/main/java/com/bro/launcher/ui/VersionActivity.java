package com.bro.launcher.ui;

/** TODO: Create version selection UI. */
public class VersionActivity {}
