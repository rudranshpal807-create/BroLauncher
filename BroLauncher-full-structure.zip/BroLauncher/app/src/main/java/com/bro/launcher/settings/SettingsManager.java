package com.bro.launcher.settings;

/** TODO: Read and persist launcher preferences. */
public class SettingsManager {}
