package com.bro.launcher.settings;

/** TODO: Configure memory limits supported by the runtime. */
public class RamManager {}
