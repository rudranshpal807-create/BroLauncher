package com.bro.launcher.auth;

/** TODO: Implement official Microsoft/Xbox/Minecraft authentication. */
public class MicrosoftAuth {}
