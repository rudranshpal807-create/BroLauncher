package com.bro.launcher.minecraft;

/** TODO: Manage Minecraft installations and game directories. */
public class MinecraftManager {}
