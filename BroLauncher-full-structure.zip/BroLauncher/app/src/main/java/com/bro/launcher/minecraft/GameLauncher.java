package com.bro.launcher.minecraft;

/** TODO: Integrate a compatible Android Java runtime and launch process. */
public class GameLauncher {}
