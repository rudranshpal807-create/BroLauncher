package com.bro.launcher.auth;

/** Minimal in-memory session model. Do not persist secrets in plain text. */
public class AuthSession {
    private final String username;
    private final String playerUuid;

    public AuthSession(String username, String playerUuid) {
        this.username = username;
        this.playerUuid = playerUuid;
    }

    public String getUsername() { return username; }
    public String getPlayerUuid() { return playerUuid; }
}
