package com.bro.launcher.minecraft;

/** TODO: Discover and select Minecraft versions. */
public class VersionManager {}
