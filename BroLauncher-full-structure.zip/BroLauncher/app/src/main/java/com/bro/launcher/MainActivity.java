package com.bro.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView title = new TextView(this);
        title.setText("BroLauncher");
        title.setTextSize(28);
        title.setPadding(32, 48, 32, 32);
        setContentView(title);
    }
}
