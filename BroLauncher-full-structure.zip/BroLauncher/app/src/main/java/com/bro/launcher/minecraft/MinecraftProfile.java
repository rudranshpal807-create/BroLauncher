package com.bro.launcher.minecraft;

/** TODO: Represent a Minecraft profile. */
public class MinecraftProfile {}
