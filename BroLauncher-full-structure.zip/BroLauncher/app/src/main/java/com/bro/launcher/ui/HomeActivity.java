package com.bro.launcher.ui;

/** TODO: Create the launcher home screen. */
public class HomeActivity {}
