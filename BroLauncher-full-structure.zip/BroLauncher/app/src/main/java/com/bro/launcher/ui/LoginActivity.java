package com.bro.launcher.ui;

/** TODO: Create the account login UI. */
public class LoginActivity {}
