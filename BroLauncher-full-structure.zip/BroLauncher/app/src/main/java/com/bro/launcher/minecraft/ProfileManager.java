package com.bro.launcher.minecraft;

/** TODO: Manage launcher profiles. */
public class ProfileManager {}
