package com.bro.launcher.download;

/** TODO: Download and verify Minecraft assets. */
public class AssetDownloader {}
