package com.bro.launcher.utils;

/** TODO: JSON parsing and serialization helpers. */
public class JsonUtils {}
