package com.bro.launcher.java;

/** TODO: Detect available Java runtimes. */
public class JavaDetector {}
