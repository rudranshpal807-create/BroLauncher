package com.bro.launcher.models;

/** TODO: Represent a Minecraft version. */
public class Version {}
