package com.bro.launcher.download;

/** TODO: Coordinate downloads with progress and cancellation. */
public class DownloadManager {}
