package com.bro.launcher.models;

/** TODO: Represent a game profile. */
public class GameProfile {}
