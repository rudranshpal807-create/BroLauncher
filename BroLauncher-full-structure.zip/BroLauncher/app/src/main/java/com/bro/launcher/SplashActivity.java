package com.bro.launcher;

import android.app.Activity;

/** TODO: Add splash screen and route to the appropriate next screen. */
public class SplashActivity extends Activity {}
