package com.bro.launcher.ui;

/** TODO: Create account management UI. */
public class AccountActivity {}
