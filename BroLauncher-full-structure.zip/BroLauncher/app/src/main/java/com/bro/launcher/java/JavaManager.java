package com.bro.launcher.java;

/** TODO: Manage compatible Java runtimes. */
public class JavaManager {}
