package com.bro.launcher.models;

/** TODO: Represent a launcher user. */
public class User {}
