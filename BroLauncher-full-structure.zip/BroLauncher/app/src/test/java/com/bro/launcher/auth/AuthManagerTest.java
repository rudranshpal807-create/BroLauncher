package com.bro.launcher.auth;

import org.junit.Test;
import static org.junit.Assert.*;

public class AuthManagerTest {
    @Test public void sessionStoresPublicProfileFields() {
        AuthSession session = new AuthSession("Player", "uuid");
        assertEquals("Player", session.getUsername());
        assertEquals("uuid", session.getPlayerUuid());
    }
}
