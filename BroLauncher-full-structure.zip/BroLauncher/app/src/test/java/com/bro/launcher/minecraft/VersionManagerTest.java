package com.bro.launcher.minecraft;

import org.junit.Test;
import static org.junit.Assert.*;

public class VersionManagerTest {
    @Test public void placeholderTestPasses() {
        assertTrue(true);
    }
}
