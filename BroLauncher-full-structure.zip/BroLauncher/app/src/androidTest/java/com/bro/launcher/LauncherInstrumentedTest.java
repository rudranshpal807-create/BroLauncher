package com.bro.launcher;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class LauncherInstrumentedTest {
    @Test public void appContextHasCorrectPackageName() {
        assertEquals("com.bro.launcher", androidx.test.platform.app.InstrumentationRegistry
                .getInstrumentation().getTargetContext().getPackageName());
    }
}
